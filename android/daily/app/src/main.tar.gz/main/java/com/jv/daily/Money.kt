package com.jv.daily

class Money (var item: String, var amount:Int, var count:Int){
}